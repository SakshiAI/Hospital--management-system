package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class ErrorController {
    @GetMapping("/error")
    public String handleError() {
        // Return a view name for your custom error page
        return "error"; // Make sure to create an error.html in the templates folder
    

}
}
