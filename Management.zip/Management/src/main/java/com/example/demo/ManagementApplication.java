package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.example.demo")
@ComponentScan(basePackages = "com.example.demo.controller")
@ComponentScan(basePackages = "com.example.demo.service")
@EnableJpaRepositories(basePackages = "com.example.demo.repository")
public class ManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagementApplication.class, args);
		System.out.println("WEL-COME APPLICATION");
	}

}
