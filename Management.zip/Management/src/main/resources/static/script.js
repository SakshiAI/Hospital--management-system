async function addPatient() {
    const patient = {
        name: document.getElementById("name").value,
        diagnosis: document.getElementById("diagnosis").value,
        age: document.getElementById("age").value,
    };

    const response = await fetch('/patients', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(patient),
    });

    const data = await response.json();
    alert(`Patient ${data.name} added successfully!`);
}

